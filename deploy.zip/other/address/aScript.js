function go()
{
    window.location.href = "https://mail.google.com/mail/u/0/#inbox?compose=DmwnWtMnZLtLbgsqZPbKmdBcwZHPvkGZNkbCwgldFnHNgFxdvjdhlMDWBbRwbXjMnpVJJLsDnWVb";
}

const back = document.getElementById("back");
back.onclick = function()
{
    window.history.back()
}